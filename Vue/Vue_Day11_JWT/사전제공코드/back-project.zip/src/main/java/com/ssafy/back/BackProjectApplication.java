package com.ssafy.back;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackProjectApplication.class, args);
	}

}
